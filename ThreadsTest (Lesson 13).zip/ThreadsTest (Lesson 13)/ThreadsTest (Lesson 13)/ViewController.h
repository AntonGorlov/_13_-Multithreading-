//
//  ViewController.h
//  ThreadsTest (Lesson 13)
//
//  Created by Anton Gorlov on 05.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

