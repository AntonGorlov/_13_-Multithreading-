//
//  AGStudent.h
//  HomeWork Lesson 13 (Multithreading)
//
//  Created by Anton Gorlov on 09.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGStudent : NSObject
@property (strong,nonatomic) NSString*name;


//уровень ученик
-(void) guessQuestion:(NSInteger) trueNumber startNumber:(NSInteger) startNumber finishNumber:(NSInteger) finishNumber;

//уровень студент -(void) guessQuestion1:(NSDictionary*) parametersDictionary block:(void(^)(void)) blockResult;
//уровень мастер -(void) guessQuestion1:(NSDictionary*) parametersDictionary block:(void(^)(float)) blockResult;

-(instancetype) initWithName:(NSString*)name;//уровень ученик

@end
