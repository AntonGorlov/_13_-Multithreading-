//
//  AGStudent.m
//  HomeWork Lesson 13 (Multithreading)
//
//  Created by Anton Gorlov on 09.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGStudent.h"
/* Уровень мастер
@interface AGStudent()
+(dispatch_queue_t)sharedQueue;
@end
*/
@implementation AGStudent

- (instancetype)initWithName:(NSString *)name
{
    self = [super init];
    if (self) {
        self.name=name;
    }
    return self;
}

//  Уровень ученик
-(void) guessQuestion:(NSInteger)trueNumber startNumber:(NSInteger)startNumber finishNumber:(NSInteger)finishNumber {
   
    void(^block)(void)=^{
         NSInteger i =0;
        //Конструкция while () {} по сути идентично циклу for. Все начинается с проверки условия окончания. Если результат ложный, выражения внутри цикла не выполняются.
        while (i !=trueNumber) {
            i=arc4random()%(finishNumber-startNumber+1)+startNumber;
        };
        NSLog(@"My name is %@, true number is %ld",self.name,i);
        
    };
    dispatch_queue_t queue=dispatch_queue_create("com.gorlov.queue", DISPATCH_QUEUE_CONCURRENT);//CONCURRENT выполняеться одновременно
    dispatch_async(queue, ^{
        block();
    });
};
 


/*
// Уровень Студент
-(void) guessQuestion1:(NSDictionary *) parametersDictionary block:(void (^)(void))blockResult {
    NSInteger trueNumber=[[parametersDictionary objectForKey:@"trueNumber"]intValue];
    NSInteger startNumber=[[parametersDictionary objectForKey:@"startNumber"]intValue];
    NSInteger finishNumber=[[parametersDictionary objectForKey:@"finishNumber"]intValue];
    void(^block)(void)=^{
        NSInteger i =0;
        //Конструкция while () {} по сути идентично циклу for. Все начинается с проверки условия окончания. Если результат ложный, выражения внутри цикла не выполняются.
        while (i !=trueNumber) {
            i=arc4random()%(finishNumber-startNumber+1)+startNumber;
        };
       dispatch_async(dispatch_get_main_queue(), ^{ //вызываем в главном потоке
           blockResult ();
       });
        
    };
    dispatch_queue_t queue=dispatch_queue_create("com.gorlov.queue", DISPATCH_QUEUE_CONCURRENT);//CONCURRENT выполняеться одновременно
    dispatch_async(queue, ^{
        block();
    });

}
*/

//мастер 10. Создать приватный метод класса (да да, приватный метод да еще и с плюсом), который будет возвращать статическую (то есть одну на все объекты класса студент) dispatch_queue_t, которая инициализируется при первом обращении к этому методу.
//11. Лучше в этом методе реализовать блок dispatch_once, ищите в инете как и зачем :) А что, программист всегда что-то ищет и хороший программист всегда находит.
//12. Все студенты должны выполнять свои процессы в этой queue и она должна быть CONCURRENT, типа все блоки одновременно выполняются

/*  мастер
   МАСТЕР НЕ РАБОТАЕТ!!
 
 +(dispatch_queue_t) sharedQueue {
    static dispatch_queue_t queue;
    static dispatch_once_t onceQueue;
    dispatch_once(&onceQueue,^{
        queue=dispatch_queue_create("com.gorlov.lesson13.threads", DISPATCH_QUEUE_CONCURRENT);
    });
    return queue;
}

-(void)guessQuestion1:(NSDictionary*) parametersDictionary block:(void(^)(float)) blockResult{
    
    NSInteger trueNumber = [[parametersDictionary objectForKey:@"trueNumber"]intValue];
    NSInteger startNumber = [[parametersDictionary objectForKey:@"startnumber"] intValue];
    NSInteger finishNumber = [[parametersDictionary objectForKey:@"finishNumber"]intValue];
    
    void(^block)(void)=^{
        double timeStart = CACurrentMediaTime();
        NSInteger i = 0;
        while (i != trueNumber) {
            i = arc4random()%(finishNumber-startNumber+1)+startNumber;
        }
        blockResult(CACurrentMediaTime()-timeStart);
    };
    
    dispatch_async([AGStudent sharedQueue], ^{
        block();
    });
}

*/
@end


