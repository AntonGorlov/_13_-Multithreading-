//
//  ViewController.h
//  HomeWork Lesson 13 (Multithreading)
//
//  Created by Anton Gorlov on 09.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

