//
//  AppDelegate.m
//  HomeWork Lesson 13 (Multithreading)
//
//  Created by Anton Gorlov on 09.11.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "AGStudent.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
   
    /*
     Я честно говоря не знаю когда вы будете напрямую использовать NSThread, я рекомендую всегда, когда надо делать что-то в бэкграунде, то использовать либо GCD (Grand Central Dispatch) либо NSOperation. Так что задание будет соответствующее :)
    */
    
/*
      Ученик.

     1. Создайте класс студент. У него должен быть метод - угадать ответ :)
     2. В метод передается случайное целое число например в диапазоне от 0 - 100 (или больше) и сам диапазон, чтобы студент знал где угадывать
     3. Студент генерирует случайное число в том же диапазоне пока оно не будет искомым
     4. Весь процесс угадывания реализуется в потоке в классе студент
     5. Когда студент досчитал то пусть пишет в НСЛог
     6. Создайте 5 студентов и дайте им одну и туже задачу и посмотрите кто справился с ней лучше
     Жени код (ученик,студент)http://vk.com/topic?act=browse_images&id=-58860049_2947
*/   
    
    AGStudent*student1=[[AGStudent alloc]initWithName:@"Polikarp"];
    AGStudent*student2=[[AGStudent alloc]initWithName:@"Ivan"];
    AGStudent*student3=[[AGStudent alloc]initWithName:@"Filip"];
    AGStudent*student4=[[AGStudent alloc]initWithName:@"Nikolay"];
    
    NSArray*studentsArray=[NSArray arrayWithObjects:student1,student2,student3,student4, nil];
    
    for (AGStudent* students in studentsArray) {
        [students guessQuestion:421 startNumber:100 finishNumber:500];
    
    }

    
/*
   Студент.
   
   7. Задача та же, но вместе с условием передавайте студенту блок, в котором вы и объявите результаты
   8. Блок должен определяться в томже классе, где и определялись студенты
   9. Блок должен быть вызван на главном потоке


    AGStudent*student1=[[AGStudent alloc]initWithName:@"Polikarp"];
    AGStudent*student2=[[AGStudent alloc]initWithName:@"Ivan"];
    AGStudent*student3=[[AGStudent alloc]initWithName:@"Filip"];
    AGStudent*student4=[[AGStudent alloc]initWithName:@"Nikolay"];
    
    NSArray*studentsArray=[NSArray arrayWithObjects:student1,student2,student3,student4, nil];
    NSInteger quessQustion=28985; //искомое число
    NSInteger startNumber=100;
    NSInteger finishNumber=1000000;

    NSDictionary* studentsDictionary =[NSDictionary dictionaryWithObjectsAndKeys:
                [NSNumber numberWithInteger:quessQustion],@"trueNumber",
                [NSNumber numberWithInteger:startNumber],@"startNumber",
                [NSNumber numberWithInteger:finishNumber],@"finishNumber", nil];
    
    
    for (AGStudent* students in studentsArray){
        void(^blockResultAppDelegate)(void)=^{
            NSLog(@"%@ I'm the winner! True number %ld",students.name,quessQustion);
        };
          [students guessQuestion1:studentsDictionary block:^{
              blockResultAppDelegate();
          }];
    
    
    }

 */    
/*
    Мастер.
    
 МАСТЕР НЕ РАБОТАЕТ!!!
    10. Создать приватный метод класса (да да, приватный метод да еще и с плюсом), который будет возвращать статическую (то есть одну на все объекты класса студент) dispatch_queue_t, которая инициализируется при первом обращении к этому методу.
    11. Лучше в этом методе реализовать блок dispatch_once, ищите в инете как и зачем :) А что, программист всегда что-то ищет и хороший программист всегда находит.
    12. Все студенты должны выполнять свои процессы в этой queue и она должна быть CONCURRENT, типа все блоки одновременно выполняются
 Жени код (мастер и супермен)http://vk.com/topic?act=browse_images&id=-58860049_2951

    NSInteger quessQustion=22548; //искомое число
    NSInteger startNumber=100;
    NSInteger finishNumber=1000000;
    
    AGStudent*student1=[[AGStudent alloc]initWithName:@"Polikarp"];
    AGStudent*student2=[[AGStudent alloc]initWithName:@"Ivan"];
    AGStudent*student3=[[AGStudent alloc]initWithName:@"Filip"];
    AGStudent*student4=[[AGStudent alloc]initWithName:@"Nikolay"];
    
    NSArray*studentsArray=[NSArray arrayWithObjects:student1,student2,student3,student4, nil];
    
    
    NSDictionary* studentsDictionary =[NSDictionary dictionaryWithObjectsAndKeys:
                                       [NSNumber numberWithInteger:quessQustion],@"trueNumber",
                                       [NSNumber numberWithInteger:startNumber],@"startNumber",
                                       [NSNumber numberWithInteger:finishNumber],@"finishNumber", nil];
    
    
    for (AGStudent* students in studentsArray){
         [students guessQuestion1:studentsDictionary block:^(float time){
            NSLog(@"%@ I'm the winner! True number %ld,%f sec",students.name,quessQustion,time);
        }];

    }
*/
    
    
    
    
    
    
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
